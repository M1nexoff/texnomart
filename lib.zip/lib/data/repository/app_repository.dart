
// abstract class AppRepository{
//   Future<List<CurrencyModel>> getCurrency({String? date});
//
// }