import 'dart:ui';

class LightColors {
  static const background = Color(0xfff4f4f4);
  static const primary = Color(0xffffbd00);
  static const white = Color(0xfff2f2f4);
  static const grey = Color(0xffcccccc);
  static const lightPeach = Color(0xffffeeb3);
  static const primary2 = Color(0xfff7f7f7);
}